import { Menu } from "./app/screens";

export default function App() {
  return <Menu />;
}
