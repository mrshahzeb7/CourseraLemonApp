const colors = {
  primary: "white",
  primaryButton: "#495E57",
  primaryButtonText: "white",
  primaryButtonDisabled: "grey",
  border: "#EDEFEE",
  lightText: "#333333",
};

export { colors };
