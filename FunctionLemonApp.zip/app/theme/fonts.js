const fontSize = {
  /**
   * 16
   */
  small: 16,

  /**
   * 20
   */
  medium: 20,
};

export { fontSize };
