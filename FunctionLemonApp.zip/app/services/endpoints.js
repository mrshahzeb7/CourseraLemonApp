const endPoints = {
  getMenu:
    "https://raw.githubusercontent.com/Meta-Mobile-Developer-PC/Working-With-Data-API/main/menu-items-by-category.json",
};

export { endPoints };
