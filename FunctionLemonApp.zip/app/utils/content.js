const sections = ["Appetizers", "Salads", "Beverages"];

export { sections };
